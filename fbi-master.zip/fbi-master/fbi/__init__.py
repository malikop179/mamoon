# -*- coding: utf-8 -*-

import settings
from client import *

__version__ = "0.1a7"

# Inint vars
settings.init()
